# Vitrine do Jota Studio 2.0

Aplicativo local-first para Android/Web, com interface responsiva em preto e azul neon.

## Recursos implementados nesta versão
- Painel com contadores e meta semanal de 14 conteúdos.
- Cadastro de conteúdos em Story, Feed, Carrossel e Reel.
- Rascunhos e fila de aprovação manual.
- Aprovar, rejeitar, editar, excluir, agendar localmente e registrar publicação manual.
- Assistente offline baseado em modelos e regras locais: gera ideias, ganchos, desenvolvimento e CTA. Não é uma IA generativa conectada a um LLM.
- Criador de artes com canvas, modelos neon/minimalista/promo, Story 9:16 e Feed 1:1, exportação PNG.
- Calendário mensal local.
- Biblioteca com busca e filtro por status.
- Backup JSON e restauração.
- Sem login, sem mensalidade e sem sincronização em nuvem.

## Limitações e segurança
- Os dados são armazenados em localStorage neste aparelho. Limpar dados do app pode apagá-los; exporte backups regularmente.
- O assistente de texto é baseado em modelos locais, não gera respostas por IA de servidor.
- As artes são layouts simples desenhados no Canvas, não imagens fotográficas geradas por IA.
- O calendário organiza horários, mas não executa tarefas em segundo plano nem publica automaticamente.
- A ação “Registrar publicação manual” apenas registra uma publicação que o usuário já realizou.
- Não há conexão com Instagram/Meta. Integração oficial depende de conta profissional elegível, permissões e configuração de aplicativo Meta; não armazene senhas do Instagram no app.
- Aprovação manual permanece obrigatória como regra do fluxo.

## Gerar APK pelo celular com GitHub Actions
1. Envie `vitrine_do_jota_studio_v2.zip` para a raiz do repositório GitHub.
2. Substitua o arquivo `.github/workflows/android-apk.yml` pelo workflow incluído neste pacote (pode enviar a pasta `.github` do ZIP ou editar o arquivo).
3. Abra Actions > Gerar APK Android > Run workflow.
4. Ao concluir, baixe o Artifact `Vitrine-do-Jota-Studio-2.0-APK`.
5. Extraia `app-debug.apk` e instale no Android.

O APK é de depuração. Para publicação na Play Store, será necessário assinar uma versão de produção e cumprir os requisitos da loja.
